import random
import os
from tkinter import *

logs = Tk()
logs.title("Karātuves")
logs.geometry("1200x900")
logs.config(bg="#E6E6E6")

# Atrod bildes directory!
script_dir = os.path.dirname(os.path.abspath(__file__))
karatuves_path = os.path.join(script_dir, "Images", "Capture.PNG")
START_POGA_path = os.path.join(script_dir, "Images", "START POGA.PNG")

# bildes
karatuves = PhotoImage(file=karatuves_path)
START_POGA = PhotoImage(file=START_POGA_path)

start = Frame(logs, bg="#E6E6E6")
start.pack()

class Start:
    def main_screen(self):
        main = Canvas(start, width=1200, height=900, bg="#E6E6E6", highlightthickness=0)
        main.pack()

        # Virsraksts
        main.create_text(600, 200, text="Karatuves", font=("MingLiU_HKSCS-ExtB", 60, "bold"))

        # Logo bilde
        main.create_image(600, 450, image=karatuves)

        # Start pogas bilde
        main.create_image(600, 750, image=START_POGA)

        # Start Button
        self.Start_poga()

    def Start_poga(self):
        start_button = Button(start, text="START", font=("MingLiU_HKSCS-ExtB", 60, "bold"), 
                              bg="#D7D7D7", activebackground="#D7D7D7", relief="flat", 
                              width=10, height=1, command=self.start_action)

        start_button.place(x=385, y=685)

    # start poga 
    def start_action(self):
        start.pack_forget()  # liek start screenam pazust
        game.pack()  # parādīs spēles ekrānu kad start scrēnds pazudīs
        spele_app.speles_screen()  # startē spēli kad tiek parādīts game screen

start_app = Start()
start_app.main_screen()
# izveido jaunu frame
game = Frame(logs, bg="#E6E6E6")

class Spele_SCREEN:
    def __init__(self):
        self.word = ""
        self.word_letters = []
        self.displayed_letters = []
        self.Lines = None
        self.vārdi = ["apelsīns", "ābols", "citrons", "melene"]  # šeit iet vārrdi !

    def speles_screen(self):
        speles_sh = Canvas(game, width=1200, height=900, bg="#E6E6E6", highlightthickness=0)
        speles_sh.pack()
        
        self.līnījas()
        self.create_buttons()

    def līnījas(self):  # izveido līnījas pa katru burtu vārdā !
        self.word = random.choice(self.vārdi)
        self.word_letters = list(self.word)
        self.displayed_letters = ["_" for _ in self.word]

        print(f"Vārds: {self.word}")  # konsolē parādās vārds kad spēle gatava komentēt !!!! 

        word_width = len(self.word) * 45  # apmēram burtu izmers pec fonta

        # Izreikina x lai centrētu vārdu!!!!!!
        canvas_width = 1200
        centered_x = (canvas_width - word_width) // 2

        self.Lines = Label(game, text=" ".join(self.displayed_letters), font=("Arial", 45, "bold"), fg="black", bg="#E6E6E6")
        self.Lines.pack(pady=10)

        #Centrē burtu!
        self.word_label = Label(game, text=" ".join(self.displayed_letters), font=("Arial", 45, "bold"), fg="black", bg="#E6E6E6")
        self.word_label.place(x=centered_x, y=300) 


    def update_display(self, letter):  # katru burtu kas tiks uzminēts tiks atjaunots ekrāns
        for i, char in enumerate(self.word_letters):
            if char == letter:
                self.displayed_letters[i] = letter
        
        # Update the word label
        self.word_label.config(text=" ".join(self.displayed_letters))

    def create_buttons(self):
        Alfabēts = "AĀBCČDEĒFGĢHIĪJKĶLĻMNŅOPRSŠTUŪVZŽ"  # alfabēetsssssssss
        # pogu pozīcījas 
        x_positions = [180, 269, 357, 445, 533, 622, 710, 798, 886, 974]
        y_positions = [430, 524, 617, 711]

        self.buttons = {}

        # sataisa pogas un sarindo tās
        for index, burts in enumerate(Alfabēts):
            row = index // 10  
            col = index % 10  

            Alfabēta_pogas = Button(game, text=burts, fg="#858585", font=("Kozuka Gothic Pr6N B", 23, "bold"), 
                         bg="#D7D7D7", activebackground="#D7D7D7", relief="flat", width=2, height=1, 
                         command=lambda l=burts: self.Burtu_Minēšana(l))
            Alfabēta_pogas.place(x=x_positions[col], y=y_positions[row])
            self.buttons[burts] = Alfabēta_pogas

    def Burtu_Minēšana(self, burts):
        if burts.lower() in self.word_letters:
            self.update_display(burts.lower())

spele_app = Spele_SCREEN()

logs.mainloop()
